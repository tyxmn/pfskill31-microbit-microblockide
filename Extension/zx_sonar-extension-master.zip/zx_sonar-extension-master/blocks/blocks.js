Blockly.defineBlocksWithJsonArray([
{
  "type": "sonar_read",
  "message0": "sonar pin: %1 read distance (cm)",
  "args0": [
    {
      "type": "input_value",
      "name": "trig"
      
    }
  ],
  "output": "Number",
  "colour": "#004098",
  "tooltip": "ZX_sonar",
  "helpUrl": ""
}
]);
