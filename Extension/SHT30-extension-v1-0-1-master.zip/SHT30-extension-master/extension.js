({
    name: "SHT30", // Category Name
    description: "Humidity and Temperature Sensor",
    author: "IOXhop.com",
    category: "Sensors",
    version: "1.0.1",
    icon: "/static/icon.png", // Category icon
    color: "#8b507c", // Category color (recommend some blocks color)
    blocks: [ // Blocks in Category
        "sht30_read"
    ]
});
